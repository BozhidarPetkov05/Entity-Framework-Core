﻿namespace Boardgames.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-58IIM9O\SQLEXPRESS;Database=Boardgames;Integrated Security=True;Encrypt=False";
    }
}
