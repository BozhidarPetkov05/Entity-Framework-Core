﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString =
            @"Server=DESKTOP-58IIM9O\SQLEXPRESS;Database=ProductShop;Integrated Security=True";
    }
}
