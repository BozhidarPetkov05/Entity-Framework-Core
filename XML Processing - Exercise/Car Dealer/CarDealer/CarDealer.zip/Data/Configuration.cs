﻿namespace CarDealer.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-58IIM9O\SQLEXPRESS;Database=CarDealer;Integrated Security=True;Encrypt=False";
    }
}
